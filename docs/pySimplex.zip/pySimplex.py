#modulo del metodo simplex en python con numpy
print "hola soy un modulo python"
